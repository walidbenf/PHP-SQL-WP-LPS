</div>
</section>
<?php wp_footer(); //Intégre les éléments de WP (css,js,barre d'administration coté front) ?>
<footer></footer>
</body>
</html>
